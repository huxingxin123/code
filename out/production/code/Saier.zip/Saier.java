import java.util.Scanner;

class user {
    private String account;

    public void welcome(){
        System.out.println("欢迎来到赛尔号");
        System.out.println("你的账户是"+account);
        System.out.println("请输入你的密码（默认密码123456）");
    }

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }
    void judgement(){
        Scanner in=new Scanner(System.in);
        int code=in.nextInt();
        if(code==123456){
            System.out.println("登录成功");
        }else {System.out.println("登录失败");
        welcome(); judgement();}
    }
}
interface Earth{
    void spirit();
}
interface Newrimuli{
    void spirit();
}
class Location {


    void section(){
        System.out.println("请选择你要进入的星球 ");
        System.out.println("1.地球    2.新日暮里");
        Scanner a=new Scanner(System.in);
        int planet=a.nextInt();
    if (planet==1){
        class Earth1 implements Earth{
            @Override
            public void spirit() {
                System.out.println("欢迎来到地球，这里有精灵佟dark伟");
            }
        }
    } else if (planet==2){
        class newrimuli1 implements Newrimuli{
            @Override
            public void spirit() {
                System.out.println("欢迎来到新日暮里，这里有精灵香蕉君");
            }
        }
    }else {System.out.println("请输入正确的数字"); section();}
    }
}
class Spirit{            //精灵类
    String name;
    void skill(){}
}
class dark extends Spirit{
    @Override
    void skill() {
        System.out.println("技能1  摔跤"+"\n"+"技能2   boy next door" );
    }
}
class banana extends Spirit{
    @Override
    void skill() {
        System.out.println("技能1  象征自由的男人"+"\n"+"技能2   凌晨四点的新日暮里");
    }
}


public class Saier {
    public static void main(String[] args) {
        user a=new user();
        a.setAccount("first player");
        a.welcome();
        a.judgement();
        Location b=new Location();
        b.section();
        System.out.println("选择你要抓捕的精灵  1.佟dark伟  2.香蕉君");
        Scanner m=new Scanner(System.in);
        int spirit=m.nextInt();
        if(spirit==1){Spirit n=new dark();
        n.name="佟dark伟";
            System.out.println("你选择了"+n.name+"他的技能是"); n.skill();}
        else if(spirit==2){Spirit j=new banana();
        j.name="香蕉君";
            System.out.println("你选择了"+j.name+"他的技能是");
        j.skill(); }

        double d = Math.random();//生成一个0~1的随机数
        if (d <= 0.5) {
            System.out.println("抓捕成功，恭喜你成为一名哲学家，向着哲学大师更近一步吧");//50%概率
        }
        else {
            System.out.println("抓捕失败"+"           失败了？你可以选择充钱变得更加强大，少年");//50%概率
            System.out.println("是否选择充钱（1.充值，我要变强，首冲抓捕精灵必中    2.不充，滚）");
            Scanner i=new Scanner(System.in);
            int  money=i.nextInt();
            if(money==1){
                System.out.println("亲爱的玩家，恭喜你抓捕成功");
            }
            else if(money==2){
                System.out.println("没钱玩腻mb，滚！");
            }
        }
    }
}


